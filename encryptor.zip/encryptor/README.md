
This is a simple python script that can encrypt and decrypt files in a folder and all its subfolders it uses strong encryption with fernet from the cryptography library

It can work with pretty much all file types including txt doc docx pdf rtf odt jpg jpeg png gif bmp tiff mp3 wav aac flac mp4 avi mov mkv zip rar 7z tar gz xls xlsx and csv

Please note I am not responsible for any stuff you do with this script use it wisely and at your own risk

To use run the script choose to encrypt or decrypt then enter the path to the folder you want to process all files in that folder and its subfolders will be encrypted or decrypted accordingly

Make sure you keep the key file safe because without it you cannot decrypt your files

If you want to contribute or report issues feel free to open a pull request or issue on github

Thank you for checking out the project

