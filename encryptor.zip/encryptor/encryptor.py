from cryptography.fernet import Fernet
import os

KEY_FILE = "key.key"
ENCRYPTED_EXTENSION = ".enc"

def load_or_create_key():
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, "rb") as f:
            key = f.read()
    else:
        key = Fernet.generate_key()
        with open(KEY_FILE, "wb") as f:
            f.write(key)
    return key

def encrypt_file(filepath, fernet):
    try:
        with open(filepath, "rb") as f:
            data = f.read()
        encrypted = fernet.encrypt(data)
        encrypted_path = filepath + ENCRYPTED_EXTENSION
        with open(encrypted_path, "wb") as f:
            f.write(encrypted)
        os.remove(filepath)
        print(f"\033[94m[+] Encrypted:\033[0m {filepath}")
    except Exception as e:
        print(f"\033[91m[!] Failed to encrypt {filepath}: {e}\033[0m")

def decrypt_file(filepath, fernet):
    try:
        with open(filepath, "rb") as f:
            data = f.read()
        decrypted = fernet.decrypt(data)
        original_path = filepath.replace(ENCRYPTED_EXTENSION, "")
        with open(original_path, "wb") as f:
            f.write(decrypted)
        os.remove(filepath)
        print(f"\033[94m[+] Decrypted:\033[0m {filepath}")
    except Exception as e:
        print(f"\033[91m[!] Failed to decrypt {filepath}: {e}\033[0m")

def process_folder_recursive(root_folder, fernet, action):
    files_to_process = []
    for root, _, files in os.walk(root_folder):
        for file in files:
            full_path = os.path.join(root, file)
            if action == 'e' and not file.endswith(ENCRYPTED_EXTENSION):
                files_to_process.append(full_path)
            elif action == 'd' and file.endswith(ENCRYPTED_EXTENSION):
                files_to_process.append(full_path)
    if not files_to_process:
        print("\033[91m[!] No matching files found to process.\033[0m")
        return
    print(f"\033[94m[+] Found {len(files_to_process)} file(s) to {'encrypt' if action == 'e' else 'decrypt'}.\033[0m")
    confirm = input("Do you want to proceed? (y/n): ").strip().lower()
    if confirm != 'y':
        print("\033[93m[*] Operation cancelled.\033[0m")
        return
    for filepath in files_to_process:
        if action == 'e':
            encrypt_file(filepath, fernet)
        elif action == 'd':
            decrypt_file(filepath, fernet)

def print_banner():
    print("\033[94m")
    print("███████ ███    ██  ██████ ██████  ██    ██ ██████  ████████  ██████  ██████  ")
    print("██      ████   ██ ██      ██   ██  ██  ██  ██   ██    ██    ██    ██ ██   ██ ")
    print("█████   ██ ██  ██ ██      ██████    ████   ██████     ██    ██    ██ ██████  ")
    print("██      ██  ██ ██ ██      ██   ██    ██    ██         ██    ██    ██ ██   ██ ")
    print("███████ ██   ████  ██████ ██   ██    ██    ██         ██     ██████  ██   ██ ")
    print("\033[0m")

def main():
    print_banner()
    key = load_or_create_key()
    fernet = Fernet(key)
    action = input("Do you want to (E)ncrypt or (D)ecrypt? ").strip().lower()
    if action not in ('e', 'd'):
        print("\033[91m[!] Invalid action. Please enter 'E' or 'D'.\033[0m")
        return
    folder = input("Enter the path to the parent folder: ").strip()
    if not os.path.isdir(folder):
        print(f"\033[91m[!] The folder '{folder}' does not exist.\033[0m")
        return
    process_folder_recursive(folder, fernet, action)

if __name__ == "__main__":
    main()

